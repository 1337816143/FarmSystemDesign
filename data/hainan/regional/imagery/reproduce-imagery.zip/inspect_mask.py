import render_previews as r
import json,numpy as np
from osgeo import gdal
x=json.load(open('output/scene-catalog.json'));s=next(s for s in x['scenes'] if s['id']=='S2C_T49PHN_20250328T024711_L2A');b=[114.03,10.875,114.12,10.955]
ds=gdal.Open('/vsicurl/'+s['assets']['scl']['href']);a=ds.ReadAsArray();m=r.mem_mask(ds,a>0)
print('native',np.unique(a,return_counts=True),'nodata',m.GetRasterBand(1).GetNoDataValue(),flush=True)
for method in ['near','max','average']:
 d=gdal.Warp('',m,format='MEM',dstSRS='EPSG:4326',outputBounds=b,width=200,height=200,resampleAlg=method,outputType=gdal.GDT_Byte,dstNodata=0,warpMemoryLimit=24);v=d.ReadAsArray();print(method,np.unique(v,return_counts=True),flush=True)
