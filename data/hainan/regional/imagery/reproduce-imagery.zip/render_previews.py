#!/usr/bin/python3
"""Reproducible public COG Range preview; no full RGB source downloads."""
import json,math,time,concurrent.futures,datetime,hashlib,sys,multiprocessing,os
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import binary_dilation
from osgeo import gdal,osr
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output'; PRE=OUT/'previews';PRE.mkdir(parents=True,exist_ok=True)
gdal.UseExceptions()
for k,v in {'GDAL_DISABLE_READDIR_ON_OPEN':'EMPTY_DIR','CPL_VSIL_CURL_ALLOWED_EXTENSIONS':'.tif','GDAL_HTTP_TIMEOUT':'55','GDAL_HTTP_MAX_RETRY':'2','CURL_CA_BUNDLE':'/etc/ssl/certs/ca-certificates.crt','GDAL_CACHEMAX':'32','VSI_CACHE':'TRUE','VSI_CACHE_SIZE':'8388608'}.items():gdal.SetConfigOption(k,v)

gdal.SetCacheMax(16*1024*1024)
CLOUD_LUT=np.zeros(256,dtype=bool);CLOUD_LUT[[3,8,9,10]]=True
CLEAR_LUT=np.zeros(256,dtype=bool);CLEAR_LUT[[2,4,5,6]]=True

def intersects(a,b):return a[0]<b[2] and a[2]>b[0] and a[1]<b[3] and a[3]>b[1]
def mem_mask(ds,a,factor=1):
 o=gdal.GetDriverByName('MEM').Create('',a.shape[1],a.shape[0],1,gdal.GDT_Byte); gt=list(ds.GetGeoTransform());gt[1]*=factor;gt[5]*=factor;o.SetGeoTransform(gt);o.SetProjection(ds.GetProjection());o.GetRasterBand(1).WriteArray(a.astype('uint8'));return o

def aggregate_mask(a,factor,op):
 if factor==1:return a
 h,w=a.shape; a=np.pad(a,((0,(-h)%factor),(0,(-w)%factor)),constant_values=False)
 b=a.reshape(a.shape[0]//factor,factor,a.shape[1]//factor,factor)
 return b.all(axis=(1,3)) if op=='all' else b.any(axis=(1,3))

def draw_scene(scene,bbox,width,height):
 t=time.time()
 cache=ROOT/'render-cache';cache.mkdir(exist_ok=True);key=hashlib.sha256((scene['id']+str(bbox)+str(width)+str(height)).encode()).hexdigest();old_cp=cache/(key+'.npz');cp=cache/('maskv2-'+key+'.npz')
 if cp.exists():
  z=np.load(cp);return scene,z['rgb'],z['clear'],z['seen'],None
 print('start scene',scene['id'],flush=True)
 try:
  sclds=gdal.Open('/vsicurl/'+scene['assets']['scl']['href']);scl=sclds.ReadAsArray();print('read scl',scene['id'],flush=True)
  cloudy=CLOUD_LUT[scl];buffered=binary_dilation(cloudy,iterations=3,brute_force=True)
  good=CLEAR_LUT[scl];good[buffered]=False;cloudy=None;buffered=None
  factor=4 if bbox[2]-bbox[0]>1 else 1
  good=aggregate_mask(good,factor,'all');seen_native=aggregate_mask(scl>0,factor,'any');scl=None;print('native mask',scene['id'],flush=True)
  common=dict(format='MEM',dstSRS='EPSG:4326',outputBounds=bbox,width=width,height=height,multithread=False,warpMemoryLimit=24)
  d=gdal.Warp('',mem_mask(sclds,good.astype('uint8')+1,factor),**common,resampleAlg='average',outputType=gdal.GDT_Float32,dstNodata=0);clear=d.ReadAsArray()>=1.999;d=None;print('warped mask',scene['id'],flush=True)
  d=gdal.Warp('',mem_mask(sclds,seen_native.astype('uint8')+1,factor),**common,resampleAlg='max',outputType=gdal.GDT_Byte,dstNodata=0);seen=d.ReadAsArray()>=2;d=None
  sclds=None;scl=None;buffered=None;good=None;cloudy=None;seen_native=None
  if old_cp.exists():
   z=np.load(old_cp);rgb=z['rgb'];z.close()
  else:
   rgbds=gdal.Open('/vsicurl/'+scene['assets']['visual']['href']);d=gdal.Warp('',rgbds,**common,resampleAlg='bilinear',srcNodata=0,dstNodata=0);rgb=d.ReadAsArray();d=None;rgbds=None
  clear &= np.any(rgb>0,axis=0)
  print('rendered',scene['id'],'secs',round(time.time()-t,1),'clear',int(clear.sum()),flush=True)
  tmp=cp.with_name(cp.name+'.tmp-'+str(os.getpid())+'.npz');np.savez_compressed(tmp,rgb=rgb,clear=clear,seen=seen);os.replace(tmp,cp)
  return scene,rgb,clear,seen,None
 except Exception as e:
  print('FAILED',scene['id'],str(e),flush=True);return scene,None,None,None,str(e)

def draw_scene_args(args):
 result=draw_scene(*args)
 scene,rgb,clear,seen,error=result
 if error:return scene,None,error
 key=hashlib.sha256((scene['id']+str(args[1])+str(args[2])+str(args[3])).encode()).hexdigest()
 return scene,str(ROOT/'render-cache'/('maskv2-'+key+'.npz')),None

def render(aoi,scenes,px_m):
 bbox=aoi['bbox'];lat=(bbox[1]+bbox[3])/2
 if aoi['id']=='main':width,height=2200,1980
 else:
  width=math.ceil((bbox[2]-bbox[0])*111320*math.cos(math.radians(lat))/px_m)
  height=math.ceil((bbox[3]-bbox[1])*111320/px_m)
  # Limit total per-window display size; source native data stays on-demand.
  ratio=max(1,max(width,height)/2000);width=math.ceil(width/ratio);height=math.ceil(height/ratio)
 selected=[s for s in scenes if intersects(s['bbox_wgs84'],bbox)]
 selected.sort(key=lambda s:(s['cloud_cover']+.35*(s.get('nodata_percent') or 0),s['datetime']))
 print('AOI',aoi['id'],width,height,'candidates',len(selected),flush=True)
 rgba=np.zeros((height,width,4),dtype='uint8');counts=np.zeros((height,width),dtype='uint8');observed=np.zeros((height,width),dtype='uint8');sourceidx=np.zeros((height,width),dtype='uint16');doy=np.zeros((height,width),dtype='uint16');sources=[];failures=[]
 # Consume in rank order, not completion order, so output is deterministic.
 with concurrent.futures.ProcessPoolExecutor(max_workers=1,max_tasks_per_child=1,mp_context=multiprocessing.get_context('spawn')) as ex:
  for idx,result in enumerate(ex.map(draw_scene_args,[(s,bbox,width,height) for s in selected]),1):
   scene,cache_path,error=result
   if error:failures.append({'scene':scene['id'],'error':error});continue
   z=np.load(cache_path);rgb=z['rgb'];clear=z['clear'];seen=z['seen'];z.close()
   observed+=seen.astype('uint8');counts+=clear.astype('uint8')
   fill=clear & (rgba[:,:,3]==0)
   rgba[fill,:3]=np.moveaxis(rgb,0,-1)[fill];rgba[fill,3]=255;sourceidx[fill]=idx
   date=scene['datetime'][:10];doy[fill]=datetime.date.fromisoformat(date).timetuple().tm_yday
   sources.append({'index':idx,'id':scene['id'],'datetime':scene['datetime'],'contributing_pixels':int(fill.sum()),'clear_pixels':int(clear.sum()),'observed_pixels':int(seen.sum())})
 image_path=PRE/(aoi['id']+'.webp');Image.fromarray(rgba).save(image_path,'WEBP',quality=86,method=6)
 np.savez_compressed(PRE/(aoi['id']+'-qa.npz'),clear_observation_count=counts,observed_count=observed,source_index=sourceidx,source_day_of_year=doy)
 # Small, browser-readable QA PNGs: 0 transparent; 1 observed but rejected; 2 accepted.
 status=np.zeros((height,width),dtype='uint8');status[observed>0]=1;status[rgba[:,:,3]>0]=2
 Image.fromarray(status).save(PRE/(aoi['id']+'-status.png'))
 Image.fromarray(counts).save(PRE/(aoi['id']+'-clear-count.png'))
 Image.fromarray(doy).save(PRE/(aoi['id']+'-source-doy.png'))
 stats={k:int(v) for k,v in {'total_bbox_pixels':width*height,'accepted_pixels':(status==2).sum(),'observed_but_rejected_pixels':(status==1).sum(),'no_source_observation_pixels':(status==0).sum()}.items()}
 used=[s for s in sources if s['contributing_pixels']]
 meta={**aoi,'quality_mask_revision':'v2_nonzero_false_true_encoding','image':str(image_path.relative_to(OUT)),'status_image':f"previews/{aoi['id']}-status.png",'clear_count_image':f"previews/{aoi['id']}-clear-count.png",'source_doy_image':f"previews/{aoi['id']}-source-doy.png",'qa_npz':f"previews/{aoi['id']}-qa.npz",'width':width,'height':height,'crs':'EPSG:4326','transform':[(bbox[2]-bbox[0])/width,0,bbox[0],0,-(bbox[3]-bbox[1])/height,bbox[3]],'display_pixel_m_at_center':[(bbox[2]-bbox[0])/width*111320*math.cos(math.radians(lat)),(bbox[3]-bbox[1])/height*111320],'native_rgb_resolution_m':10,'native_scl_resolution_m':20,'stats':stats,'accepted_bbox_percent':round(stats['accepted_pixels']/stats['total_bbox_pixels']*100,3),'denominator':'All display cells in this rectangular geographic window, including water and any unrelated land. Not administrative land coverage.','sources':sources,'failures':failures,'actual_contributing_dates':sorted(set(s['datetime'][:10] for s in used)),'image_bytes':image_path.stat().st_size,'image_sha256':hashlib.sha256(image_path.read_bytes()).hexdigest(),'status_legend':{'0':'No source observation among selected scenes (transparent)','1':'Observed but no accepted clear pixel (transparent); includes cloud/shadow/cirrus, unclassified, saturated/snow or mask-edge rejection','2':'Accepted display pixel'},'processing':{'rgb':'Native 10m TCI display values (uint8) read by HTTP Range and bilinear reprojected. No reflectance scaling applied to TCI.','scl':'Mask warp uses explicit false=1,true=2 to prevent zero exclusion by statistical resampling; threshold1.999. Read native 20m SCL. Accept classes2,4,5,6. Reject0,1,3,7,8,9,10,11. Dilate cloud/shadow/cirrus classes3,8,9,10 by3native pixels(60m); require >=99.9% clear fraction for each output cell. For broad main-island preview only, conservative4x4 all-clear blocks reduce native20m mask to80m before reprojection; observed mask uses any-observed blocks.','mosaic':'First accepted pixel in scene cloud%+0.35*nodata% rank order. Multi-date best-available display; not a median, single-date image, or independently certified cloud-free product.','cloud_audit_limit':'SCL may miss haze/thin cloud or misclassify land/water; overviews and resampling lower display detail. Remaining holes stay transparent. Counts cover selected candidates only, not all 2025 observations.'}}
 json.dump(meta,open(PRE/(aoi['id']+'.json'),'w'),ensure_ascii=False,indent=2)
 print('COMPLETE AOI',aoi['id'],stats,meta['image_bytes'],flush=True);return meta

def main(ids):
 inventory=json.load(open(ROOT/'aoi-inventory.json'))
 target_catalog=OUT/'scene-catalog-main-xisha-zhongsha-nansha.json'
 if ids==['main']:target_catalog=OUT/'scene-catalog-main.json'
 while not target_catalog.exists():print('waiting scenes',flush=True);time.sleep(10)
 scenes=json.load(open(target_catalog))['scenes']
 aois=[g for g in inventory['groups'] if g['id']=='main']+inventory['places']
 results=[]
 for a in aois:
  if ids and a['id'] not in ids:continue
  px=10 if a.get('kind') in ['nearshore-sample','island-sample'] else 20
  p=PRE/(a['id']+'.json')
  if p.exists():results.append(json.load(open(p)));continue
  results.append(render(a,scenes,px))
 json.dump({'aoi_status':'Query and display envelopes only; exhaustive provincial land/reef coverage unresolved.','previews':results},open(OUT/('preview-manifest-'+('-'.join(ids) or 'all')+'.json'),'w'),ensure_ascii=False,indent=2)
if __name__=='__main__':main(sys.argv[1:])
