#!/usr/bin/python3
import sys,json,gzip,urllib.request,time,concurrent.futures,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
CACHE=ROOT/'selected-items';CACHE.mkdir(exist_ok=True)
SELECTION='For each MGRS grid within each query envelope, choose three distinct acquisitions ranked by scene cloud_percent + 0.35*nodata_percent. Scene metadata ranking is not pixel-quality verification. Full 2025 catalog pagination exhausted in each query envelope.'
def full(item):
 p=CACHE/(item['id']+'.json')
 if p.exists():return json.load(open(p))
 u='https://earth-search.aws.element84.com/v1/collections/sentinel-2-c1-l2a/items/'+item['id']
 for attempt in range(4):
  try:
   with urllib.request.urlopen(u,timeout=60) as r:x=json.load(r)
   json.dump(x,open(p,'w'),separators=(',',':'));return x
  except Exception as e:
   if attempt==3:raise
   time.sleep(2+2*attempt)
def select(items,n=3):
 by=collections.defaultdict(list)
 for x in items:by[x['properties'].get('grid:code') or ('MGRS-'+x['id'].split('_')[1][1:])].append(x)
 selected=[]
 for grid,rows in sorted(by.items()):
  def score(x):p=x['properties'];return (p.get('eo:cloud_cover',100)+.35*p.get('s2:nodata_pixel_percentage',0),p['datetime'])
  rows.sort(key=score);selected.extend(rows[:n])
 return selected

def flatten(i,groups):
 p=i['properties']; assets={}
 for key in ['visual','red','green','blue','scl']:
  a=i['assets'][key];r=a.get('raster:bands',[{}])[0]
  assets[key]={'href':a['href'],'native_resolution_m':a['gsd'],'shape':a['proj:shape'],'transform':a['proj:transform'],'nodata':r.get('nodata',0),'data_type':r.get('data_type'),'file_size':a.get('file:size'),'checksum':a.get('file:checksum')}
  if key in ['red','green','blue']:assets[key].update(scale=r.get('scale'),offset=r.get('offset'))
 return {'id':i['id'],'mgrs':p.get('grid:code'),'datetime':p['datetime'],'cloud_cover':p.get('eo:cloud_cover'),'nodata_percent':p.get('s2:nodata_pixel_percentage'),'bbox_wgs84':i['bbox'],'epsg':p['proj:epsg'],'assets':assets,'query_groups':sorted(groups),'used_by':[]}

def main(names):
 catalogs={}
 for name in names:
  path=ROOT/'catalogs'/f'{name}.json.gz'
  while not path.exists():print('waiting for exhausted catalog',name,flush=True);time.sleep(15)
  catalogs[name]=json.load(gzip.open(path,'rt'))
  assert catalogs[name]['pagination_exhausted']
 chosen={};groups=collections.defaultdict(set)
 for name,c in catalogs.items():
  for i in select(c['features']):chosen[i['id']]=i;groups[i['id']].add(name)
 print('fetching selected full items',len(chosen),flush=True)
 allfull=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
  for n,i in enumerate(ex.map(full,chosen.values()),1):
   allfull.append(i)
   if n%20==0:print('fetched',n,len(chosen),flush=True)
 flat=[flatten(i,groups[i['id']]) for i in allfull]
 out={'collection':'sentinel-2-c1-l2a','period':'2025-01-01/2025-12-31','selection':SELECTION,'preview_display':'Source TCI RGB visual display is native 10 m; no reflectance scale is applied to TCI. Quantitative RGB bands require DN*scale+offset after nodata mask.','groups':[{k:v for k,v in c.items() if k!='features'}|{'id':name} for name,c in catalogs.items()],'scenes':flat}
 json.dump(out,open(OUT/('scene-catalog-'+ '-'.join(names)+'.json'),'w'),separators=(',',':'))
 json.dump(out,open(OUT/'scene-catalog.json','w'),separators=(',',':'))
 print('COMPLETE',len(flat),'scenes',len(set(x['mgrs'] for x in flat)),'MGRS',flush=True)
if __name__=='__main__':main(sys.argv[1:] or ['main','xisha','zhongsha','nansha'])
