#!/usr/bin/python3
import json,gzip,urllib.request,urllib.parse,time,os,concurrent.futures
from pathlib import Path
ROOT=Path(__file__).resolve().parent
API='https://earth-search.aws.element84.com/v1/search'
DATE='2025-01-01T00:00:00Z/2025-12-31T23:59:59Z'
INVENTORY=json.load(open(ROOT/'aoi-inventory.json'))
GROUPS={g['id']:g['bbox'] for g in INVENTORY['groups']}
KEEP_PROPS=['datetime','eo:cloud_cover','proj:epsg','grid:code','s2:nodata_pixel_percentage','s2:processing_baseline','s2:cloud_shadow_percentage','s2:water_percentage']
def get(url):
 for attempt in range(5):
  try:
   with urllib.request.urlopen(url,timeout=90) as r:return json.load(r)
  except Exception as e:
   if attempt==4:raise
   print('retry',attempt,type(e).__name__,flush=True);time.sleep(2+attempt*2)
def compact(i):
 return {'type':'Feature','id':i['id'],'bbox':i['bbox'],'geometry':i['geometry'],'properties':{k:v for k,v in i['properties'].items() if k in KEEP_PROPS},'assets':{k:{kk:vv for kk,vv in v.items() if kk in ['href','raster:bands','gsd','proj:shape','proj:transform','file:size','file:checksum']} for k,v in i.get('assets',{}).items() if k in ['red','green','blue','visual','scl','preview']}}
def collect(name,bbox):
 output=ROOT/'catalogs'/f'{name}.json.gz';output.parent.mkdir(exist_ok=True)
 if output.exists():
  x=json.load(gzip.open(output,'rt'))
  if x.get('pagination_exhausted'):return {'group':name,'count':len(x['features']),'pages':x['pages']}
 u=API+'?'+urllib.parse.urlencode({'collections':'sentinel-2-c1-l2a','bbox':','.join(map(str,bbox)),'datetime':DATE,'limit':1000,'fields':'-assets,-links,properties.eo:cloud_cover,properties.grid:code,properties.proj:epsg,properties.s2:nodata_pixel_percentage,properties.s2:processing_baseline'})
 items={};pages=0;matched=None
 while u:
  x=get(u);pages+=1;matched=x.get('numberMatched',matched)
  for i in x['features']:items[i['id']]=compact(i)
  nxt=next((l for l in x['links'] if l['rel']=='next'),None);u=nxt['href'] if nxt else None
  if u:
   parts=urllib.parse.urlsplit(u); q=urllib.parse.parse_qs(parts.query)
   q['fields']=['-assets,-links,properties.eo:cloud_cover,properties.grid:code,properties.proj:epsg,properties.s2:nodata_pixel_percentage,properties.s2:processing_baseline']
   u=urllib.parse.urlunsplit((parts.scheme,parts.netloc,parts.path,urllib.parse.urlencode(q,doseq=True),''))
  print(name,'page',pages,'unique',len(items),'matched',matched,flush=True)
  if pages>1000:raise RuntimeError('Pagination runaway; not exhausted')
 if matched is not None and len(items)!=matched:raise RuntimeError('Exhausted pagination but unique count differs from numberMatched; investigate catalogue mutation or retrieval')
 final={'collection':'sentinel-2-c1-l2a','api':API,'datetime_filter':DATE,'bbox':bbox,'pages':pages,'number_matched':matched,'unique_items':len(items),'pagination_exhausted':True,'coverage_warning':'Catalogue intersections are not valid-pixel coverage or administrative extents.','features':list(items.values())}
 with gzip.open(output,'wt') as f:json.dump(final,f,separators=(',',':'))
 return {'group':name,'count':len(items),'pages':pages}
if __name__=='__main__':
 import sys
 names=sys.argv[1:] or list(GROUPS)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for result in ex.map(lambda name:collect(name,GROUPS[name]),names):print('COMPLETE',result,flush=True)
