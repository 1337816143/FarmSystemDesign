#!/usr/bin/python3
import json,hashlib,shutil,platform
from pathlib import Path
import numpy as np
from PIL import Image
from osgeo import gdal
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';PRE=OUT/'previews'
def finalize():
 records=[];checks=[]
 for p in sorted(PRE.glob('*.json')):
  m=json.load(open(p));assert m.get('quality_mask_revision')=='v2_nonzero_false_true_encoding'; aoi=m['id']; arr=np.array(Image.open(OUT/m['image']).convert('RGBA'));qa=np.load(OUT/m['qa_npz']);status=np.array(Image.open(OUT/m['status_image']))
  assert arr.shape[:2]==status.shape
  assert np.array_equal(arr[:,:,3]>0,status==2),(aoi,'alpha mismatch')
  assert np.array_equal(qa['clear_observation_count']>0,status==2)
  assert np.array_equal(qa['source_day_of_year']>0,status==2)
  assert (np.isin(status,[0,1,2])).all()
  assert m['stats']['accepted_pixels']==int((status==2).sum())
  assert sum(m['stats'][k] for k in ['accepted_pixels','observed_but_rejected_pixels','no_source_observation_pixels'])==status.size
  if aoi=='main':
   maskpath=ROOT/'../cache/main-island-mask-100m.tif'
   if not maskpath.exists():maskpath=OUT/'main-island-mask-100m.tif'
   if maskpath.exists():
    d=gdal.Warp('',str(maskpath),format='MEM',dstSRS='EPSG:4326',outputBounds=m['bbox'],width=m['width'],height=m['height'],resampleAlg='nearest');land=d.ReadAsArray()==1;d=None
    m['approx_main_island_land_audit']={'mask':'Esri2025 connected-main-island 100m source-class mask with interior lakes filled; nearest resampled to display grid. Not an administrative boundary; small islands excluded.','land_display_pixels':int(land.sum()),'accepted_land_display_pixels':int(((status==2)&land).sum()),'observed_but_rejected_land_display_pixels':int(((status==1)&land).sum()),'no_source_land_display_pixels':int(((status==0)&land).sum()),'accepted_land_percent':round(float(((status==2)&land).sum()/land.sum()*100),4),'mask_source_path':'main-island-mask-100m.tif','uncertainty':'Display-grid fraction, not native 10m land completeness or area. Includes 100m mask and mixed/coastal-pixel uncertainty.'}
    if maskpath.resolve()!=(OUT/'main-island-mask-100m.tif').resolve():shutil.copy2(maskpath,OUT/'main-island-mask-100m.tif')
    json.dump(m,open(p,'w'),ensure_ascii=False,indent=2)
  records.append({'id':aoi,'name_zh':m.get('name_zh',aoi),'group':m.get('group',aoi),'preview':m['image'],'bounds_wsen':m['bbox'],'pixel_size_degrees':[m['transform'][0],-m['transform'][4]],'width':m['width'],'height':m['height'],'metadata':str(p.relative_to(OUT)),'status_preview':m['status_image'],'clear_count_preview':m['clear_count_image'],'source_date_preview':m['source_doy_image'],'qa_npz':m['qa_npz'],'source_date_encoding':'uint16 day-of-year in2025;0nodata','native_rgb_m':10,'native_scl_m':20,'display_pixel_m_at_center':m['display_pixel_m_at_center'],'coverage':m['stats'],'approx_main_island_land_audit':m.get('approx_main_island_land_audit'),'actual_contributing_dates':m['actual_contributing_dates'],'failed_sources':len(m['failures'])})
  checks.append({'aoi':aoi,'status':'passed','accepted_pixels':m['stats']['accepted_pixels'],'rgba_sha256':m['image_sha256'],'failed_sources':len(m['failures'])})
 catalog=json.load(open(OUT/'scene-catalog.json'))
 by={s['id']:s for s in catalog['scenes']}
 for s in by.values():s['used_by']=[]
 for r in records:
  m=json.load(open(OUT/r['metadata']))
  for s in m['sources']:
   if s['contributing_pixels'] and s['id'] in by:by[s['id']]['used_by']=sorted(set(by[s['id']]['used_by']+[r['id']]))
 json.dump(catalog,open(OUT/'scene-catalog.json','w'),separators=(',',':'))
 mf={'collection':catalog['collection'],'period':catalog['period'],'attribution':'Contains modified Copernicus Sentinel data(2025), processed from Element84 Earth Search C1 L2A COGs','scope':'Main-island/nearshore and offshore geographic envelopes plus named display windows; not administrative boundaries or exhaustive provincial island coverage.','scene_catalog':'scene-catalog.json','selection':catalog['selection'],'records':records,'status':'Derived real RGB with transparent missing/rejected pixels. Cloud/haze and completeness not independently certified.'}
 json.dump(mf,open(OUT/'preview-manifest.json','w'),ensure_ascii=False,indent=2)
 shutil.copy2(ROOT/'aoi-inventory.json',OUT/'aoi-inventory.json');shutil.copy2(ROOT/'README.md',OUT/'README.md')
 files=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='verification.json']
 v={'verified_utc':'2026-10-03','checks':checks,'file_count':len(files),'total_bytes':sum(f['bytes'] for f in files),'below_30mb':sum(f['bytes'] for f in files)<30000000,'source_scene_count':len(catalog['scenes']),'mgrs_count':len(set(s['mgrs'] for s in catalog['scenes'])),'query_groups':[{'id':g['id'],'unique_items':g['unique_items'],'number_matched':g['number_matched'],'pages':g['pages'],'pagination_exhausted':g['pagination_exhausted']} for g in catalog['groups']],'software':{'python':platform.python_version(),'gdal':gdal.VersionInfo()},'files':files}
 assert v['below_30mb'],v['total_bytes']
 json.dump(v,open(OUT/'verification.json','w'),indent=2)
 print(json.dumps({k:v[k] for k in ['total_bytes','source_scene_count','mgrs_count','query_groups']},indent=2))
if __name__=='__main__':finalize()
