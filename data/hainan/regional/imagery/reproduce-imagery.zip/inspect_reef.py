import json
import numpy as np
from osgeo import gdal
for k,v in {'GDAL_DISABLE_READDIR_ON_OPEN':'EMPTY_DIR','CPL_VSIL_CURL_ALLOWED_EXTENSIONS':'.tif','CURL_CA_BUNDLE':'/etc/ssl/certs/ca-certificates.crt'}.items():gdal.SetConfigOption(k,v)
x=json.load(open('output/scene-catalog.json')); sid='S2C_T49PHN_20250328T024711_L2A';s=next(s for s in x['scenes'] if s['id']==sid);b=[114.03,10.875,114.12,10.955]
for k in ['scl','visual']:
 ds=gdal.Open('/vsicurl/'+s['assets'][k]['href']);o=gdal.Warp('',ds,format='MEM',dstSRS='EPSG:4326',outputBounds=b,width=200,height=200,resampleAlg='near');a=o.ReadAsArray();print(k,'gt',ds.GetGeoTransform(),'shape',a.shape,'classes' if k=='scl' else 'zero',np.unique(a,return_counts=True) if k=='scl' else np.sum(a.sum(axis=0)==0),flush=True)
 if k=='scl':
  print('center',a[100,100]);from PIL import Image;Image.fromarray(a).save('reef-scl.png')
