#!/usr/bin/python3
import json,gzip,concurrent.futures
from pathlib import Path
from prepare_scenes import full,flatten
root=Path(__file__).resolve().parent;out=root/'output'
gaps=json.load(open(root/'main-gap-candidates.json'));chosen=[];grids=set()
for gap in gaps:
 if not gap['candidates']:continue
 sid=gap['candidates'][0]['id'];grid=sid.split('_')[1]
 if grid in grids:continue
 grids.add(grid);chosen.append({'id':sid,'target_gap_centroid_wgs84':gap['centroid'],'target_gap_pixels_at_selection':gap['gap_pixels']})
 if len(chosen)==3:break
items={s['id']:s for s in json.load(gzip.open(root/'catalogs/main.json.gz','rt'))['features']}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:extra=[flatten(i,['main']) for i in ex.map(full,[items[s['id']] for s in chosen])]
for s in extra:s['selection_reason']='Additional candidate targeting remaining main-island masked gaps; ranked scene cloud% +0.1*nodata% among geometrically containing gap centroid.'
for name in ['scene-catalog.json','scene-catalog-main-xisha-zhongsha-nansha.json','scene-catalog-main.json']:
 c=json.load(open(out/name));existing={s['id'] for s in c['scenes']};c['scenes'].extend(s for s in extra if s['id'] not in existing);c['additional_main_gap_candidates']=chosen;json.dump(c,open(out/name,'w'),separators=(',',':'))
json.dump(chosen,open(out/'main-gap-additional-candidates.json','w'),indent=2)
print('ADDED',len(extra),'gap candidates',chosen)
