#!/usr/bin/python3
"""Regression tests: false mask pixels must not disappear during average/max warp."""
import numpy as np,json
from osgeo import gdal,osr
from render_previews import mem_mask
srs=osr.SpatialReference();srs.ImportFromEPSG(4326)
ds=gdal.GetDriverByName('MEM').Create('',80,80,1,gdal.GDT_Byte);ds.SetProjection(srs.ExportToWkt());ds.SetGeoTransform([110,.001,0,20,0,-.001])
results=[]
for name,a in [('all_false',np.zeros((80,80),dtype='uint8')),('all_true',np.ones((80,80),dtype='uint8')),('half',np.pad(np.ones((80,40),dtype='uint8'),((0,0),(40,0))))]:
 encoded=mem_mask(ds,a+1)
 out=gdal.Warp('',encoded,format='MEM',dstSRS='EPSG:4326',outputBounds=[110,19.92,110.08,20],width=160,height=160,resampleAlg='average',outputType=gdal.GDT_Float32,dstNodata=0,warpMemoryLimit=24).ReadAsArray()
 ratio=float((out>=1.999).mean());expected={'all_false':0,'all_true':1,'half':.5}[name]
 assert abs(ratio-expected)<.02,(name,ratio)
 results.append({'case':name,'accepted_fraction':ratio,'expected':expected})
print(json.dumps({'status':'passed','tests':results},indent=2))
