#!/usr/bin/python3
import json,gzip,concurrent.futures
from osgeo import ogr
from pathlib import Path
from prepare_scenes import full,flatten
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output'
inv=json.load(open(ROOT/'aoi-inventory.json'));cat=json.load(open(OUT/'scene-catalog.json'));by={s['id']:s for s in cat['scenes']};add={};selections=[]
for a in inv['places']:
 if a['id'] not in ['zhubi','huangyan']:continue
 b=a['bbox']; poly=ogr.CreateGeometryFromJson(json.dumps({'type':'Polygon','coordinates':[[[b[0],b[1]],[b[2],b[1]],[b[2],b[3]],[b[0],b[3]],[b[0],b[1]]]]}));area=poly.GetArea()
 items=json.load(gzip.open(ROOT/'catalogs'/(a['group']+'.json.gz'),'rt'))['features'];rank=[]
 for i in items:
  bb=i['bbox']
  if not(bb[0]<b[2] and bb[2]>b[0] and bb[1]<b[3] and bb[3]>b[1]):continue
  geom=ogr.CreateGeometryFromJson(json.dumps(i['geometry']));inter=geom.Intersection(poly);ratio=inter.GetArea()/area if inter else 0
  p=i['properties'];score=p.get('eo:cloud_cover',100)+200*(1-ratio)
  rank.append((score,ratio,i))
 rank.sort(key=lambda t:t[0]);chosen=rank[:3];selections.append({'aoi':a['id'],'rule':'Add 3 candidates ranked by scene cloud% +200*(1-STAC geometric overlap fraction of named window). Geometric overlap remains distinct from observed pixel coverage.','scenes':[{'id':i['id'],'footprint_overlap_fraction':ratio,'score':score} for score,ratio,i in chosen]})
 for _,_,i in chosen:
  if i['id'] not in by:add[i['id']]=(i,a['group'])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for item in ex.map(lambda t:full(t[0]),add.values()):
  s=flatten(item,[add[item['id']][1]]);s['selection_reason']='additional_named_AOI_geometric_coverage_candidate';by[s['id']]=s
cat['scenes']=list(by.values());cat['additional_aoi_candidates']=selections
for p in ['scene-catalog.json','scene-catalog-main-xisha-zhongsha-nansha.json']:json.dump(cat,open(OUT/p,'w'),separators=(',',':'))
json.dump(selections,open(OUT/'aoi-additional-candidates.json','w'),indent=2)
print('added',len(add),'total',len(by));print(json.dumps(selections,indent=2))
