#!/usr/bin/env python3
"""Verify all bundled inputs and scripts against package-sha256.json, offline."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
entries=json.loads((root/'package-sha256.json').read_text())
errors=[]
for row in entries:
 p=root/row['file']
 if not p.exists():errors.append(row['file']+': missing');continue
 if p.stat().st_size!=row['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:errors.append(row['file']+': mismatch')
if errors:raise SystemExit('\n'.join(errors))
print(str(len(entries))+' package files verified')
