#!/usr/bin/env python3
"""Verify the public scientific tag allowlist without echoing removed values."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
ALLOW=set(json.loads((ROOT/'sanitization-policy.json').read_text())['allowed_source_tags'])
URL=re.compile(r'(?:https?://|ftp://|www\.|(?:[a-z0-9-]+\.)+(?:com|org|net|ms|cn|io|edu|gov)(?:[/?:#]|\b))',re.I)
def check(tags,file):
 for k,v in tags.items():
  if k not in ALLOW or URL.search(str(v)):raise SystemExit('Unexpected source field in '+file+': '+k)
for f in (ROOT/'raw').glob('*.osm'):
 for obj in ET.parse(f).getroot():check({t.attrib['k']:t.attrib['v'] for t in obj.findall('tag')},f.name)
for f in (ROOT/'raw').glob('*.geojson'):
 for obj in json.loads(f.read_text()).get('features',[]):
  p=obj['properties'];tags=dict(re.findall(r'"([^"]+)"=>"([^"]*)"',p.get('other_tags','')));check(tags,f.name)
print('All bundled OSM tags pass the public allowlist and URL-value filter')
