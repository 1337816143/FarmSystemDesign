#!/usr/bin/env python3
"""Compare generated artifacts with the frozen expected outputs; no network."""
import argparse,hashlib,json
from pathlib import Path
source=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,default=source/'output');a=p.parse_args()
expected=json.loads((source/'expected-output-sha256.json').read_text())
errors=[]
for r in expected:
 f=a.output_dir/r['file']
 if not f.exists():errors.append(r['file']+': missing');continue
 actual=hashlib.sha256(f.read_bytes()).hexdigest()
 if actual!=r['sha256']:errors.append(r['file']+': SHA-256 mismatch')
if errors:raise SystemExit('\n'.join(errors))
print(str(len(expected))+' frozen output files match byte for byte')
