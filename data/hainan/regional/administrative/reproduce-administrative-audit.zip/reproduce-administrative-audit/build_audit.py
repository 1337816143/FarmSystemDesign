#!/usr/bin/env python3
"""Rebuild public OSM audit artifacts. Run /usr/bin/python3 build_audit.py.
No network calls. GDAL/OGR and pyproj are required; raw source snapshots stay separate.
"""
import argparse,collections,csv,datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
from osgeo import ogr,gdal
from pyproj import Geod
SOURCE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Reproduce the sanitized public 2026-10-03 OSM audit from bundled allowlisted inputs, offline.')
parser.add_argument('--output-dir',type=Path,default=SOURCE/'output',help='Destination for public derived artifacts')
parser.add_argument('--reassemble',action='store_true',help='Reassemble administrative geometry from bundled sanitized XML using GDAL')
args=parser.parse_args()
D=args.output_dir.resolve();D.mkdir(parents=True,exist_ok=True)
RAW=SOURCE/'raw'
source_meta=json.loads((SOURCE/'source-inputs.json').read_text())
SOURCE_PBF_SHA256=source_meta['source_pbf_sha256']
CACHED=RAW/'cached-administrative-subset.geojson'
NAMED_SUBSET=RAW/'cached-named-islands.geojson'
ADMIN_ASSEMBLED=RAW/'sansha-assembled.geojson'
PUBLIC_POLICY=json.loads((SOURCE/'sanitization-policy.json').read_text())
ORIGINAL_ARTIFACT_SHA256=json.loads((SOURCE/'original-artifact-sha256.json').read_text())
if args.reassemble:
 work=D/'_intermediate';work.mkdir(exist_ok=True)
 ADMIN_ASSEMBLED=work/'sansha-assembled.geojson'
 subprocess.run(['ogr2ogr','-overwrite','--config','OSM_CONFIG_FILE',str(SOURCE/'osmconf-audit.ini'),'-f','GeoJSON',str(ADMIN_ASSEMBLED),str(RAW/'sansha-full.osm'),'multipolygons','-where',"boundary = 'administrative'"],check=True)
GEOD=Geod(ellps='WGS84')
def save(name,data):
 if name in ORIGINAL_ARTIFACT_SHA256:
  data['original_source_sha256']=ORIGINAL_ARTIFACT_SHA256[name]
  data['sanitization']=PUBLIC_POLICY
 (D/name).write_text(json.dumps(data,ensure_ascii=False,**({'separators':(',',':')} if name.endswith('.geojson') else {'indent':2}))+'\n')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def tags(el):return {t.attrib['k']:t.attrib['v'] for t in el.findall('tag')}
def geo(f):return ogr.CreateGeometryFromJson(json.dumps(f['geometry']))
def bbox(g):
 x0,x1,y0,y1=g.GetEnvelope();return [x0,y0,x1,y1]
def valid(g):
 gdal.PushErrorHandler('CPLQuietErrorHandler');v=bool(g.IsValid());gdal.PopErrorHandler();return v

def area_km2(f):
 # Ring orientation is arbitrary in OSM; subtract inner-ring magnitudes explicitly.
 return round(sum(abs(GEOD.polygon_area_perimeter(*zip(*p[0]))[0])-sum(abs(GEOD.polygon_area_perimeter(*zip(*r))[0]) for r in p[1:]) for p in f['geometry']['coordinates'])/1e6,6)

root=ET.parse(RAW/'sansha-full.osm').getroot()
rels={e.attrib['id']:e for e in root.findall('relation')}
ways={e.attrib['id']:e for e in root.findall('way')}
nodes={e.attrib['id']:e for e in root.findall('node')}
data=json.loads(ADMIN_ASSEMBLED.read_text())
fs={f['properties']['osm_id']:f for f in data['features']}
assert set(fs)=={'2833102','6753119','6753150','6753263'}
relation_rows=[];clean=[]
limitations=[
 'Community-maintained OSM administrative reference, not an authoritative surveyed or legally current administrative boundary.',
 'Child source descriptions restrict their scope to the part described by OSM contributors as controlled by China. That description has not been independently verified here and is not a statement on sovereignty.',
 'These polygons include sea. They are not island outlines, a terrestrial land mask, an exhaustive island/reef inventory, or the full legal/claimed maritime extent.',
 'Zhongsha relation 6753119 retains legacy name/code 460323 and is stored as a separate OSM subarea. Official 2020 district structure has Xisha and Nansha, with Xisha administering Zhongsha; the legacy OSM row must not become a third current district.',
 'OSM edit timestamps are object-edit dates, not dates of authoritative survey. A relation date alone does not date all member ways or nodes.',
 'ODbL re-use permission and attribution do not establish public-map approval, official cartographic compliance, sovereignty, or statistical-join correctness.',
 'Completeness is verified only for referenced outer-way/node geometry of these four OSM objects in the downloaded snapshot; completeness of real-world administration or islands remains unverified.'
]
for rid in ['2833102','6753150','6753263','6753119']:
 f=fs[rid];g=geo(f);r=rels[rid];ts=tags(r);members=[dict(m.attrib) for m in r.findall('member')]
 outers=[m['ref'] for m in members if m['type']=='way' and m['role']=='outer']; inners=[m['ref'] for m in members if m['type']=='way' and m['role']=='inner']
 missingways=[w for w in outers+inners if w not in ways]
 missingnodes=[n.attrib['ref'] for w in outers+inners if w in ways for n in ways[w].findall('nd') if n.attrib['ref'] not in nodes]
 allcoords={(float(nodes[n.attrib['ref']].attrib['lon']),float(nodes[n.attrib['ref']].attrib['lat'])) for w in outers+inners for n in ways[w].findall('nd')}
 outputcoords=[tuple(c) for p in f['geometry']['coordinates'] for ring in p for c in ring]
 rings=[ring for p in f['geometry']['coordinates'] for ring in p]
 row={'osm_relation_id':int(rid),'name':ts['name'],'osm_version':int(r.attrib['version']),'osm_timestamp':r.attrib['timestamp'],'source_admin_level':ts.get('admin_level'),'source_division_code':ts.get('division_code'),'source_url':'https://www.openstreetmap.org/relation/'+rid,'source_api_url':'https://api.openstreetmap.org/api/0.6/relation/'+rid+'/full','source_tags':ts,'members':members,'outer_way_count':len(outers),'inner_way_count':len(inners),'missing_outer_inner_ways':missingways,'missing_outer_inner_nodes':missingnodes,'geometry_type':f['geometry']['type'],'polygon_count':g.GetGeometryCount(),'coordinate_count_including_ring_closure':len(outputcoords),'all_rings_closed':all(x[0]==x[-1] for x in rings),'all_geometries_valid':valid(g),'all_coordinates_from_source_nodes':all(c in allcoords for c in outputcoords),'all_source_boundary_coordinates_used':set(outputcoords)==allcoords,'bbox_wgs84':bbox(g),'geodesic_polygon_area_including_sea_km2':area_km2(f),'official_complete_boundary':False,'is_land_mask':False,'is_complete_island_inventory':False,'scope_status':'source-defined OSM partial reference; not official whole jurisdiction'}
 assert row['all_geometries_valid'] and row['all_rings_closed'] and not missingways and not missingnodes
 assert row['all_coordinates_from_source_nodes'] and row['all_source_boundary_coordinates_used']
 relation_rows.append(row)
 p={k:row[k] for k in ['name','osm_relation_id','osm_version','osm_timestamp','source_admin_level','source_division_code','source_url','scope_status','official_complete_boundary','is_land_mask','is_complete_island_inventory']}
 p.update(snapshot_download_date='2026-10-03',license='ODbL-1.0',attribution='© OpenStreetMap contributors',reference_kind='community administrative reference, includes sea; not official',scope_label_zh='OSM社区部分范围参考，含海域；非官方完整行政界',statistical_join_approved=False)
 if rid=='6753119':p.update(hierarchy_status='legacy separate OSM subarea; do not count as a third current district',official_current_parent_context='西沙区代管中沙岛礁及其海域')
 clean.append({'type':'Feature','properties':p,'geometry':f['geometry']})

gs={rid:geo(f) for rid,f in fs.items()}
u=gs['6753150'].Union(gs['6753263']).Union(gs['6753119'])
diff=gs['2833102'].SymDifference(u)
outersets={rid:{m.attrib['ref'] for m in rels[rid].findall('member') if m.attrib['type']=='way' and m.attrib['role']=='outer'} for rid in rels}
assert outersets['2833102']==set.union(outersets['6753150'],outersets['6753263'],outersets['6753119'])
assert diff.IsEmpty()
base={'type':'FeatureCollection','name':'OSM Sansha source-defined partial administrative reference 2026-10-03','properties':{'license':'ODbL-1.0','license_url':'https://opendatacommons.org/licenses/odbl/1-0/','attribution':'© OpenStreetMap contributors','crs':'EPSG:4326','source_snapshot':'raw/sansha-full.osm','limitations':limitations}}
for filename,select in [('sansha-osm-reference-20261003.geojson',clean[:1]),('sansha-osm-subareas-20261003.geojson',clean[1:])]:
 out=dict(base);out['features']=select;save(filename,out)

cached=json.loads(CACHED.read_text());old={f['properties']['osm_id']:f for f in cached['features'] if f['properties'].get('osm_id')}
cachecomparison={rid:{'present_in_prior_assembled_cache':rid in old,'matches_api_geometry_topologically':gs[rid].SymDifference(geo(old[rid])).IsEmpty() if rid in old else None} for rid in gs}
fetch=json.loads((SOURCE/'fetch-log.json').read_text())
extra=RAW/'relation-metadata.osm'
if not any(x['file']=='raw/relation-metadata.osm' for x in fetch):
 fetch.insert(0,{'file':'raw/relation-metadata.osm','url':'https://api.openstreetmap.org/api/0.6/relations?relations=6753150,6753119,6753263','download_date':'2026-10-03','status':200,'bytes':extra.stat().st_size,'sha256':digest(extra),'note':'Initial bounded read; exact request clock not recorded. Raw payload frozen.'})
save('fetch-log.json',fetch)

# Source-bounded named-object inventory. No administrative membership is inferred.
named=json.loads(NAMED_SUBSET.read_text())['features']
inv=[];validfs=[]
for f in named:
 p=f['properties'];typ='relation' if p.get('osm_id') else 'way';oid=p.get('osm_id') or p['osm_way_id'];g=geo(f);ok=valid(g)
 row={'osm_type':typ,'osm_id':int(oid),'name':p['name'],'source_place':p.get('place'),'source_natural':p.get('natural'),'osm_version':p.get('osm_version'),'osm_timestamp':str(p.get('osm_timestamp','')).rstrip('Z')+'Z','source_url':f'https://www.openstreetmap.org/{typ}/{oid}','geometry_valid':ok,'bbox_wgs84':bbox(g),'geometry_type':f['geometry']['type'],'administrative_membership':'not asserted','inventory_scope':'named polygonal island/islet/reef OSM objects in cached Geofabrik Hainan extract; incomplete and not deduplicated by physical feature','source_snapshot_date':'2026-10-03','license':'ODbL-1.0'}
 extra_tags=dict(re.findall(r'"([^"]+)"=>"([^"]*)"',p.get('other_tags','')))
 point=g.PointOnSurface() if ok else None
 if point is not None:assert g.Intersects(point)
 row.update(name_zh=extra_tags.get('name:zh') or (p['name'] if re.search(r'[\u3400-\u9fff]',p['name']) else None),name_en=extra_tags.get('name:en'),valid_geometry=ok,bbox=row['bbox_wgs84'],source_date='2026-10-03',representative_point=[point.GetX(),point.GetY()] if point is not None else None,representative_point_method='OGR PointOnSurface of valid source polygon (display/sample locator, not administrative centre)' if point is not None else 'none: invalid source geometry',representative_lon=point.GetX() if point is not None else None,representative_lat=point.GetY() if point is not None else None,source_tags=extra_tags)
 inv.append(row)
 if ok:validfs.append({'type':'Feature','properties':row,'geometry':f['geometry']})
save('named-island-reef-object-inventory.json',{'record_kind':'source OSM object inventory, not an island count or census','source_pbf_sha256':SOURCE_PBF_SHA256,'selection':"name IS NOT NULL AND (place = 'island' OR place = 'islet' OR natural = 'reef') in GDAL multipolygons layer; no spatial clipping or administrative join",'limitations':['Includes main Hainan Island and nearshore/offshore named objects. Same names may occur on island and reef polygons or multiple objects.','Only polygonal objects assembled from this extract. Unnamed objects, point-only islands and areas outside the extract are not covered.','Southern Nansha geography is outside the cached extract. The acquired Nansha administrative polygon does not supply the missing island/reef inventory.','Invalid source geometries are recorded here and excluded from the valid geometry layer; no automatic geometry repair was performed.'],'objects':inv})
save('named-island-reef-valid-reference.geojson',{'type':'FeatureCollection','name':'Geofabrik Hainan cached named island/islet/reef objects; source-bounded, non-exhaustive','properties':{'license':'ODbL-1.0','attribution':'© OpenStreetMap contributors','license_url':'https://opendatacommons.org/licenses/odbl/1-0/','inventory_file':'named-island-reef-object-inventory.json','complete_census':False,'administrative_membership_asserted':False},'features':validfs})
with (D/'named-island-reef-object-inventory.csv').open('w',newline='') as fp:
 cols=['osm_type','osm_id','name','name_zh','name_en','source_place','source_natural','osm_version','osm_timestamp','source_url','geometry_valid','valid_geometry','bbox_wgs84','bbox','representative_point','representative_lon','representative_lat','representative_point_method','source_date','administrative_membership'];w=csv.DictWriter(fp,fieldnames=cols);w.writeheader();w.writerows({k:r[k] for k in cols} for r in inv)
report={'audit_date':'2026-10-03','status':'source OSM parent and child reference geometries acquired and verified; official full jurisdiction and island completeness remain missing','source':'OpenStreetMap contributors; official OSM API read-only snapshots plus previously downloaded Geofabrik extract','license':'ODbL-1.0','license_url':'https://opendatacommons.org/licenses/odbl/1-0/','attribution':'© OpenStreetMap contributors','geometry_crs':'EPSG:4326','transformation':'GDAL OSM assembly from source outer ways. No coordinate editing, simplification, buffer, bounding-box polygon, geometry repair or invented union used for delivered parent geometry. Parent sourced directly from OSM relation 2833102.','relations':relation_rows,'topology_checks':{'parent_equals_union_of_three_osm_subareas':bool(diff.IsEmpty()),'parent_outer_way_set_equals_subarea_outer_way_union':True,'scope_of_check':'OSM geometry only; does not approve source hierarchy or territorial claims'},'prior_cache_comparison':cachecomparison,'named_object_inventory':{'records':len(inv),'distinct_names':len({x['name'] for x in inv}),'valid_polygonal_objects':len(validfs),'invalid_objects':[x for x in inv if not x['geometry_valid']],'complete_census':False,'island_count':None},'network':{'new_raw_response_bytes':sum(x.get('original_source_bytes',x['bytes']) for x in fetch),'calls':len(fetch),'overpass_called':False,'method_reason':'Known object IDs resolved from cached data and bounded OSM parent relation API. Reused local PBF instead of broad Overpass scans or large regional downloads.','raw_responses':fetch},'software':{'gdal':gdal.VersionInfo('--version')},'limitations':limitations,'remaining_gaps':[{'item':'Authoritative current complete administrative GIS boundaries and approved display','status':'missing','needed':'Officially supplied or user-authorized/licensed WGS84/known-CRS GIS vector, version/date, source authority, permitted publication scope and any required map-review identifiers. A statistical table or generic web-map JSON is insufficient.'},{'item':'Exhaustive full-province island/reef inventory and terrestrial mask','status':'missing','needed':'Defined reference inventory with persistent island/reef identifiers, geometry/coordinates, tide/dry-land convention and coverage including southern Nansha. OSM named-object subset is only a starting list.'},{'item':'Administrative/statistical joins','status':'unapproved','needed':'Explicitly reconcile the official 19 city/county statistical rows, current Xisha/Nansha district hierarchy and source partial geometries. Do not allocate statistics to sea polygons.'}]}
save('audit.json',report)
outputs=[p for p in D.rglob('*') if p.is_file() and p.name!='sha256-manifest.json']
save('sha256-manifest.json',[{'file':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(outputs)])
print(json.dumps({'relation_polygons':{x['name']:x['polygon_count'] for x in relation_rows},'relation_areas_including_sea_km2':{x['name']:x['geodesic_polygon_area_including_sea_km2'] for x in relation_rows},'cache_comparison':cachecomparison,'named_objects':report['named_object_inventory']['records'],'invalid_objects':[(x['name'],x['osm_type'],x['osm_id']) for x in inv if not x['geometry_valid']],'response_bytes':report['network']['new_raw_response_bytes']},ensure_ascii=False,indent=2))
